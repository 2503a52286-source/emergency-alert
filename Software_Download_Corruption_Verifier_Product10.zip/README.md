# Software Download Corruption Verifier

## Product 10
Software Download Corruption Verifier — CRC-based file integrity checker.

### Problem
A user downloads or copies a ZIP/binary software package. An incomplete download or
storage problem may alter the package. The application checks whether the downloaded
file matches the original reference file.

### Technology
- Python
- Flask
- CRC-32
- HTML/CSS

### Run on Windows

1. Open the project folder in VS Code.
2. Open Terminal.
3. Run:
   `py -m venv venv`
4. Activate:
   `venv\Scripts\activate`
5. Install:
   `pip install -r requirements.txt`
6. Start:
   `py app.py`
7. Open:
   `http://127.0.0.1:5000`

### How to demonstrate
1. Select the original/reference ZIP or binary file.
2. Select its downloaded/copy version.
3. Click "Verify File Integrity".
4. Same CRC-32 -> no detectable accidental corruption.
5. Different CRC-32 -> possible corruption/change detected.

### Important
CRC is for accidental error detection. It is not encryption, authentication, or a
guarantee against deliberate tampering.
