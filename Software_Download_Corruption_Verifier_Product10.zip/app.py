from flask import Flask, render_template, request
import os
import zlib

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024

def crc32_file(file_obj):
    crc = 0
    while True:
        chunk = file_obj.read(1024 * 1024)
        if not chunk:
            break
        crc = zlib.crc32(chunk, crc)
    return f"{crc & 0xffffffff:08X}"

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None

    if request.method == "POST":
        reference = request.files.get("reference")
        downloaded = request.files.get("downloaded")

        if not reference or not downloaded or not reference.filename or not downloaded.filename:
            error = "Please select both the original reference file and the downloaded/copy file."
        else:
            ref_crc = crc32_file(reference.stream)
            down_crc = crc32_file(downloaded.stream)
            match = ref_crc == down_crc

            result = {
                "reference_name": reference.filename,
                "downloaded_name": downloaded.filename,
                "reference_crc": ref_crc,
                "downloaded_crc": down_crc,
                "match": match
            }

    return render_template("index.html", result=result, error=error)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
